![logo](/Home.png)

**YOUTUBE VIDEO BY : NONE**


**ECONOMY BOT BY XLELORDS**


**𝐂𝐇 ⸙ XLE CLAN**

***

## Installation Guide

<br/>

- in `config.json` Adjust the PREFIX.
- in `.env` Adjust the TOKEN
- `Enable All Intents`
<br/>


***
